import Swal from '../../dist/sweetalert2.all.js'

Swal.fire('hello world')
